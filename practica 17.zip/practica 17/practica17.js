var numero1=0;
var numero2=0;

alert("Bienvenido a la  calculador de aleta maxima");

numero1 = parseInt(prompt("Ingrese un numero"));

alert("Muy bien ahora vamos por el segundo valor");

numero2 = parseInt(prompt("Ingrese el otro numero"));


alert("Ahora vamos escoger la operacion que deseas realziar");

var option = prompt("Menu de opciones:"+
"\n1. Sumar (x)"+
"\n2. Restar (y)"+
"\n3. Multiplicar (z)"+
"\n4. Dividir (w)"
); 

var valor = parseInt(option);

switch (valor) {
    case 1:
        var x = numero1+numero2;
        //var x = parseInt(numero1)+parseInt(numero2);
        alert("El resultado de {"+numero1+" + "+numero2+"} = "+x);
        break;
        case 2:
            var y =numero1-numero2;
            alert("El resultado de {"+numero1+" - "+numero2+"} = "+y);
            break;
            case 3:
                var z =numero1*numero2;
                alert("El resultado de {"+numero1+" * "+numero2+"} = "+z);
                break;
                case 4:
                    var w =numero1/numero2;
                    alert("El resultado de {"+numero1+" / "+numero2+"} = "+w);
                    break;
    default:
        alert("No haz selecionado ninguna de la opciones del menu.");
        break;
}