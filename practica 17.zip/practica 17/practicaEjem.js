var numero1 = 3;
var numero2 = 5;

resultado = numero1 > numero2; //resultado en false
resultado = numero1 < numero2; //resultado en True

alert(resultado);


numero1 = 5;
numero2 = 5;

resultado = numero1 >= numero2; // result en True
resultado = numero1 <= numero2; // result en True
resultado = numero1 == numero2; // result en True
resultado = numero1 != numero2; // result en False

alert(resultado);